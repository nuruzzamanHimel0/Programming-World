<?php

class Student{

  public function describe(){

    echo "describe method exist";
  }

 
}

?>